package com.yekta.dinamikduvar

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.min

/**
 * Ekran her açıldığında (onVisibilityChanged(true)) kısa bir animasyon oynatır:
 * Galatasaray aslanı, logoya doğru hafifçe yükselirken yavaşça Osimhen'e dönüşür.
 * Animasyon bitince son kare (Osimhen) sabit kalır; ekran tekrar kapanıp açıldığında
 * animasyon baştan (aslan) başlar.
 */
class DinamikDuvarService : WallpaperService() {

    override fun onCreateEngine(): Engine = TransformEngine()

    private inner class TransformEngine : Engine() {

        // --- Referans tasarım tuvali (aslanın alındığı ekran görüntüsünün çözünürlüğü) ---
        private val refW = 1116f
        private val refH = 2480f

        // Bu dikdörtgenler referans tuval üzerinde, görselin NİHAİ (ekranda görünecek) boyut
        // ve konumunu tanımlar. drawBitmap kaynağı otomatik olarak bu dikdörtgene ölçekler.
        private val logoRect = RectF(390f, 752f, 390f + 343f, 752f + 454f)
        private val lionRect = RectF(0f, 1660f, 0f + 650f, 1660f + 660f)
        private val osimScale = 1.404f
        private val osimRect = RectF(-220f, 1748f, -220f + 1002f * osimScale, 1748f + 560f * osimScale)

        // Figürün logoya doğru yükseldiği mesafe (referans birimde)
        private val risePx = 110f

        private val animDurationMs = 3000L
        private val frameIntervalMs = 16L // ~60fps

        private var lionBmp: Bitmap? = null
        private var osimBmp: Bitmap? = null
        private var logoBmp: Bitmap? = null

        private var surfaceScale = 1f
        private var visible = false
        private var startTime: Long? = null
        private var lastProgress = 0f

        private val handler = Handler(Looper.getMainLooper())
        private val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val addPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        }

        private val drawRunnable = object : Runnable {
            override fun run() {
                if (!visible) return
                val now = SystemClock.uptimeMillis()
                val start = startTime ?: now.also { startTime = it }
                val elapsed = now - start
                val t = min(1f, elapsed / animDurationMs.toFloat())
                drawFrame(easeInOut(t))
                lastProgress = t
                if (t < 1f) {
                    handler.postDelayed(this, frameIntervalMs)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            lionBmp = loadAsset("lion.png")
            osimBmp = loadAsset("osimhen.png")
            logoBmp = loadAsset("logo.png")
        }

        private fun loadAsset(name: String): Bitmap? = try {
            assets.open(name).use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceScale = width / refW
            drawFrame(if (lastProgress >= 1f) 1f else 0f)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                // Ekran her açıldığında animasyonu baştan (aslan) oynat.
                startTime = null
                handler.removeCallbacks(drawRunnable)
                handler.post(drawRunnable)
            } else {
                handler.removeCallbacks(drawRunnable)
            }
        }

        private fun easeInOut(t: Float): Float = t * t * (3f - 2f * t)

        private fun scaledRect(r: RectF, shiftPx: Float): RectF {
            return RectF(
                r.left * surfaceScale,
                r.top * surfaceScale - shiftPx,
                r.right * surfaceScale,
                r.bottom * surfaceScale - shiftPx
            )
        }

        private fun drawFrame(t: Float) {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                canvas.drawColor(Color.BLACK)

                val shift = risePx * surfaceScale * t

                logoBmp?.let {
                    canvas.drawBitmap(it, null, scaledRect(logoRect, 0f), drawPaint)
                }

                lionBmp?.let {
                    if (t < 1f) {
                        drawPaint.alpha = ((1f - t) * 255).toInt()
                        canvas.drawBitmap(it, null, scaledRect(lionRect, shift), drawPaint)
                        drawPaint.alpha = 255
                    }
                }

                osimBmp?.let {
                    if (t > 0f) {
                        addPaint.alpha = (t * 255).toInt()
                        canvas.drawBitmap(it, null, scaledRect(osimRect, shift), addPaint)
                    }
                }
            } finally {
                canvas?.let { holder.unlockCanvasAndPost(it) }
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            handler.removeCallbacks(drawRunnable)
            lionBmp?.recycle()
            osimBmp?.recycle()
            logoBmp?.recycle()
        }
    }
}
